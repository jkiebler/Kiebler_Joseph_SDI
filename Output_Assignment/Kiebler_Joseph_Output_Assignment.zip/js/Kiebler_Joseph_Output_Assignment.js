//Define variables

//String Variable; Define type of car driven
var myCar = "2006 Nissan Maxima";
//Number Variable; Define length of time lived in this area
var livedHere = 22;
//Boolean Variable; Define validity of love for music
var loveMusic = true;


//Body of code

//Output car driven to console with contextual statement
console.log("I drive a " + myCar + ".");
//Output length of time lived in area to console with contextual statement
console.log("I have lived in this area for " + livedHere + " years.");
//Output validity of love for music
console.log("It is " + loveMusic + " that I love all kinds of music, but rock more than any other.");